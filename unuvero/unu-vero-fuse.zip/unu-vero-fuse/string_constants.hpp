#pragma once

#include <string>



namespace strconst
{
	const std::string path = "path";
	const std::string body = "body";
	const std::string details = "details";
	const std::string items = "items";
	const std::string folders = "folders";
	const std::string headers = "headers";
	const std::string name    = "name";
}
