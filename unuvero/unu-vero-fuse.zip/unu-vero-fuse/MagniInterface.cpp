/*
 * MagniAuth.cpp
 *
 *  Created on: Aug 28, 2015
 *      Author: gsilverman
 */
#include <algorithm>
#include <string>
#include <utility>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <cassert>

#include <boost/algorithm/string/replace.hpp>

#include <boost/network/protocol/http.hpp>
#include <boost/network/uri/builder.hpp>
#include <boost/system/system_error.hpp>

#include "MagniInterface.hpp"

using namespace boost::network;

Json::Value MagniInterface::_search_response;

MagniInterface::~MagniInterface() {
	// TODO Auto-generated destructor stub
}

MagniInterface::MagniInterface(const std::string& p_root_url) : _root_url(p_root_url) {
	// TODO Auto-generated constructor stub

}


Json::Value
MagniInterface::authenticate
  (const std::string& p_email,
   const std::string& p_password)
{
	this->_email = p_email;
	Json::Value headers_and_body;
	headers_and_body["error"] = Json::Value(Json::objectValue);
	headers_and_body[strconst::headers] = Json::Value(Json::objectValue);


	boost::network::uri::uri auth_uri;
	boost::network::uri::builder urib(auth_uri);

	urib.scheme("https").host(this->_root_url).path("/thor/auth/magni");
	urib.query("email",this->_email);
	urib.query("password",p_password);
	urib.query("web_sesion","false");

	this->_request.uri(auth_uri);

	this->_response = this->_client.post(this->_request);

	try
	{
		this->_response.status();
	}
	catch(boost::system::system_error& syserr)
	{
		headers_and_body["error"] = Json::Value(Json::objectValue);
		headers_and_body["error"]["error_code"] = syserr.code().value();
		headers_and_body["error"]["message"] = syserr.code().message();
		return headers_and_body;
	}

	headers_range<http_client::response>::type headers_ = this->_response.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	body_range<http_client::response>::type body_;


	body_ = body(this->_response).range();

	std::ostringstream oss;

	oss.str("");
	oss << body_;

	Json::Value jvalue;
	Json::Reader jreader;

	jreader.parse(oss.str(), jvalue);

	headers_and_body[strconst::body] = jvalue;

	this->_request << boost::network::header("Memeo-Magni-Auth-Token", headers_and_body[strconst::body]["magni_token"].asString());

	return headers_and_body;

}

Json::Value
MagniInterface::search
	()
{

	Json::Value headers_and_body;
	headers_and_body["error"] = Json::Value(Json::objectValue);

	boost::network::uri::uri search_uri;
	boost::network::uri::builder urib(search_uri);

	urib.scheme("https").host(this->_root_url).path("/thor/magni/admin/search");
	urib.query("include_docs","true");
	urib.query("limit","100");
	urib.query("reverse","false");
	urib.query("sort",strconst::name);

	this->_request.uri(search_uri);

	this->_response = this->_client.get(this->_request);
	headers_range<http_client::response>::type headers_ = this->_response.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	body_range<http_client::response>::type body_;


	body_ = body(this->_response).range();

	std::ostringstream oss;

	oss.str("");
	oss << body_;

	Json::Value body;
	Json::Reader jreader;

	jreader.parse(oss.str(), body);

	Json::StyledWriter writer;

	/**
	 * create folder structure representation
	 */

	Json::Value fs = Json::Value(Json::objectValue);
	std::ostringstream oss_index;
	std::vector<std::string> splits;
	std::map<std::string,std::map<std::string,Json::Value>> dirfs;
	Json::Value::Members members;
	Json::Value crumbs;
	std::vector<std::string> path_components;
	std::string name;
	std::string path;

	std::vector<std::string> paths;
	Json::Value folders = Json::Value(Json::objectValue);
	folders["/"] = Json::Value(Json::objectValue);
	folders["/"]["metadata"] = Json::Value(Json::objectValue);
	folders["/"][strconst::items]    = Json::Value(Json::objectValue);
	Json::Value items = Json::Value(Json::objectValue);

	Json::Value itembody;
	for(Json::ArrayIndex i =0;i<body["rows"].size();++i) {

		Json::Value item_url = body["rows"][i];
		this->_request.uri(item_url["links"]["file"].asString());
		this->_response = this->_client.get(this->_request);
		body_range<http_client::response>::type response_itembody = boost::network::http::body(this->_response).range();
		oss.str("");
		oss << response_itembody;
		jreader.parse(oss.str(),itembody);

		name = itembody[strconst::name].asString();
		path_components.clear();
		path_components.push_back(itembody[strconst::path].asString());
		path_components.push_back(name);
		path = boost::join(path_components,"/");
		if(path[0]!='/')
		{
			path.insert(path.begin(),'/');
		}
		paths.push_back(path);
		if(itembody["is_folder"].asBool())
		{
			folders[path] = Json::Value(Json::objectValue);
			folders[path]["metadata"] = Json::Value(Json::objectValue);
			folders[path][strconst::items]    = Json::Value(Json::objectValue);
		}
		items[path] = itembody;

	}

	for(auto&& item : items)
	{
		path = "/"+ item[strconst::path].asString();
		const std::string& name = item[strconst::name].asString();
		folders[path][strconst::items][name] = item;
	}
	headers_and_body[strconst::body] = body;
	headers_and_body[strconst::body][strconst::details][strconst::folders] = folders;
	headers_and_body[strconst::body][strconst::details][strconst::items]   = items;


	MagniInterface::_search_response = headers_and_body;
	return headers_and_body;

}

int MagniInterface::fuse_getattr(const char *path, struct stat *stbuf) {
	int res = 0;

	printf("\n---------\n%s: %s\n", __FUNCTION__, path);
	memset(stbuf, 0, sizeof(struct stat));

	if (!_search_response[strconst::body][strconst::details][strconst::folders][path].isNull()) {
		stbuf->st_mode = S_IFDIR | 0755;
		stbuf->st_nlink = 2+_search_response[strconst::body][strconst::details][strconst::folders][path][strconst::items].size();
	} else if (!_search_response[strconst::body][strconst::details][strconst::items][path].isNull()) {
		stbuf->st_mode = S_IFREG | 0444;
		stbuf->st_nlink = 1;
		stbuf->st_size = _search_response[strconst::body][strconst::details][strconst::items][path]["size"].asUInt64();
	} else {
		res = -ENOENT;
	}
	if(res!=-ENOENT)
	{
		if(!_search_response[strconst::body][strconst::details][strconst::items][path]["changed_at"].isNull())
		{
			const char *changed_at_time = _search_response[strconst::body][strconst::details][strconst::items][path]["changed_at"].asCString();
			tm tmval;
			strptime(changed_at_time,"%Y-%m-%dT%H:%M:%S",&tmval);
			time_t t = mktime(&tmval);
			stbuf->st_mtim = {t,0};
		}
	}
	return res;
}

int MagniInterface::fuse_readdir(const char *path, void *buf, fuse_fill_dir_t filler,
		off_t offset, struct fuse_file_info *fi) {

	(void) offset;
	(void) fi;

	printf("\n---------\n%s: %s\n", __FUNCTION__, path);
	fflush(stdout);
	std::vector<std::string> members;

	Json::Value folder =
			_search_response[strconst::body][strconst::details][strconst::folders][path][strconst::items];
	if (!folder.isNull()) {
		std::cout << Json::StyledWriter().write(folder) << std::endl;
		int offset = 0;
		filler(buf, ".", NULL, 0);
		filler(buf, "..", NULL, 0);
		members = folder.getMemberNames();
		for (auto&& member : members) {
			const char *name = folder[member][strconst::name].asCString();
			filler(buf, name + offset, NULL, 0);
		}
		return 0;
	} else {
		return -ENOENT;
	}

}


int MagniInterface::fuse_open(const char *path, struct fuse_file_info *fi) {
	printf("\n---------\n%s: %s\n", __FUNCTION__, path);
	fflush(stdout);

	return -ENOENT;
}


int MagniInterface::fuse_read(const char *path, char *buf, size_t size, off_t offset,
		struct fuse_file_info *fi) {
	printf("\n---------\n%s: %s\n", __FUNCTION__, path);
	return -ENOENT;

}

int MagniInterface::fuse_release(const char *path, struct fuse_file_info *fi) {
	printf("\n---------\n%s: %s\n", __FUNCTION__, path);
	fflush(stdout);
	return -ENOENT;

}

fuse_operations MagniInterface::get_operations() {
	this->_fuse_operations = {0};
	this->_fuse_operations.getattr = MagniInterface::fuse_getattr;
	this->_fuse_operations.readdir = MagniInterface::fuse_readdir;
	this->_fuse_operations.open = MagniInterface::fuse_open;
	this->_fuse_operations.read = MagniInterface::fuse_read;
	this->_fuse_operations.release = MagniInterface::fuse_release;
	this->_fuse_operations.readlink = readlink;
	return this->_fuse_operations;
}
