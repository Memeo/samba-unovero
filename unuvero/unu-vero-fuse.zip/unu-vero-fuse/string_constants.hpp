#pragma once

#include <string>



namespace strconst
{
	const std::string path         = "path";
	const std::string body         = "body";
	const std::string details    = "details";
	const std::string items      = "items";
	const std::string folders    = "folders";
	const std::string headers    = "headers";
	const std::string name       = "name";
	const std::string error        = "error";
	const std::string error_code   = "error_code";
	const std::string message      = "message";
	const std::string links        = "links";
	const std::string rows         = "rows";
	const std::string file         = "file";
	const std::string slash        = "/";
	const std::string metadata     = "metadata";
	const std::string https        = "https";
	const std::string is_folder    = "is_folder";
	const std::string size         = "size";
	const std::string changed_at   = "changed_at";
	const std::string true_str     = "true";
	const std::string false_str    = "false";
	const std::string include_docs = "include_docs";
	const std::string limit        = "limit";
	const std::string email        = "email";
	const std::string password     = "password";
	const std::string web_session  = "web_session";
	const std::string magni_token_header = "Memeo-Magni-Auth-Token";
	const std::string magni_token        = "magni_token";
	const std::string reverse            = "reverse";
	const std::string sort               = "sort";
	const std::string auth_path          = "/thor/auth/magni";
	const std::string search_path        = "/thor/magni/admin/search";
	const std::string download_link      = "download_link";
	const std::string download           = "download";
	const std::string accept             = "accept";
    const std::string accept_encoding    = "accept-encoding";
    const std::string bifrost_encoding   = "application/vnd.memeo.bifrost.v1.0";
    const std::string gzip_deflate_encoding = "gzip, deflate";
}
