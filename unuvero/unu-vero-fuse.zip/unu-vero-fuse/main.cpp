
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <map>
#include <unistd.h>
#include <sys/types.h>


#include "MagniInterface.hpp"



static fuse_operations magni_fuse_operations;

int main(int argc, char *argv[]) {

	std::cout << std::boolalpha << std::endl;
	MagniInterface& ma = MagniInterface::instance("magni-staging.memeo.com");

	Json::Value response;

	response = ma.authenticate("greg.silverman@mailinator.com","passw0rd1");

	response = ma.search();

	magni_fuse_operations = ma.get_operations();

	return fuse_main(argc, argv, &magni_fuse_operations, NULL);

}
