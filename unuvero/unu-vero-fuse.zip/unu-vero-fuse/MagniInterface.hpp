/*
 * MagniAuth.hpp
 *
 *  Created on: Aug 28, 2015
 *      Author: gsilverman
 */

#ifndef MAGNIINTERFACE_HPP_
#define MAGNIINTERFACE_HPP_

#include <boost/network/protocol/http.hpp>

#include <jsoncpp/json/value.h>
#include <jsoncpp/json/reader.h>
#include <jsoncpp/json/writer.h>
#include <fuse.h>

#include "string_constants.hpp"

class MagniInterface {
public:
	typedef boost::network::http::basic_client<
			boost::network::http::tags::http_async_8bit_tcp_resolve, 1, 0> http_client;
	virtual ~MagniInterface();
	MagniInterface(const std::string& p_root_url);
	Json::Value authenticate(const std::string& p_email,const std::string& p_password);
	Json::Value search();
	static int fuse_getattr(const char *path, struct stat *stbuf);
	static int fuse_readdir(const char *path, void *buf, fuse_fill_dir_t filler,off_t offset, struct fuse_file_info *fi);
	static int fuse_open(const char *path, struct fuse_file_info *fi);
	static int fuse_read(const char *path, char *buf, size_t size, off_t offset,struct fuse_file_info *fi);
	static int fuse_release(const char *path, struct fuse_file_info *fi);
	fuse_operations get_operations();
private:
	http_client _client;
	http_client::request _request;
	http_client::response _response;
	std::string _root_url;
	std::string _email;

	fuse_operations _fuse_operations;

	static Json::Value _search_response;
};

#endif /* MAGNIINTERFACE_HPP_ */
