/*
 * MagniAuth.cpp
 *
 *  Created on: Aug 28, 2015
 *      Author: gsilverman
 */


#include <algorithm>
#include <string>
#include <utility>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>
#include <cassert>
#include <errno.h>
#include <memory>

#include <boost/algorithm/string/replace.hpp>

#include <boost/network/protocol/http.hpp>
#include <boost/network/uri/builder.hpp>
#include <boost/system/system_error.hpp>

#include "MagniInterface.hpp"

using namespace boost::network;

Json::Value MagniInterface::_search_response;

MagniInterface *MagniInterface::_instance = 0;

MagniInterface&
MagniInterface::instance
	(const std::string& p_root_url)
{
	if(!_instance)
	{
		_instance = new MagniInterface(p_root_url);
	}
	return *_instance;
}
MagniInterface::~MagniInterface() {
	// TODO Auto-generated destructor stub
}

MagniInterface::MagniInterface(const std::string& p_root_url) : _root_url(p_root_url) {
	// TODO Auto-generated constructor stub

}


Json::Value
MagniInterface::authenticate
  (const std::string& p_email,
   const std::string& p_password)
{
	this->_email = p_email;
	Json::Value headers_and_body;
	headers_and_body[strconst::error] = Json::Value(Json::objectValue);
	headers_and_body[strconst::headers] = Json::Value(Json::objectValue);


	boost::network::uri::uri auth_uri;
	boost::network::uri::builder urib(auth_uri);

	urib.scheme(strconst::https).host(this->_root_url).path(strconst::auth_path);
	urib.query(strconst::email,this->_email);
	urib.query(strconst::password,p_password);
	urib.query(strconst::web_session,strconst::false_str);

	this->_request.uri(auth_uri);

	this->_response = this->_client.post(this->_request);

	try
	{
		this->_response.status();
	}
	catch(boost::system::system_error& syserr)
	{
		headers_and_body[strconst::error] = Json::Value(Json::objectValue);
		headers_and_body[strconst::error][strconst::error_code] = syserr.code().value();
		headers_and_body[strconst::error][strconst::message] = syserr.code().message();
		return headers_and_body;
	}

	headers_range<http_client::response>::type headers_ = this->_response.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	body_range<http_client::response>::type body_;


	body_ = body(this->_response).range();

	std::ostringstream oss;

	oss.str("");
	oss << body_;

	Json::Value jvalue;
	Json::Reader jreader;

	jreader.parse(oss.str(), jvalue);

	headers_and_body[strconst::body] = jvalue;

	this->_magni_token = headers_and_body[strconst::body][strconst::magni_token].asString();

	return headers_and_body;

}

Json::Value
MagniInterface::search
	()
{
	std::ostringstream oss;

	Json::Value headers_and_body;
	headers_and_body[strconst::error] = Json::Value(Json::objectValue);

	boost::network::uri::uri search_uri;
	boost::network::uri::builder urib(search_uri);

	urib.scheme(strconst::https).host(this->_root_url).path(strconst::search_path);
	urib.query(strconst::include_docs,strconst::true_str);
	oss << 100;
	urib.query(strconst::limit,oss.str());
	urib.query(strconst::reverse,strconst::false_str);
	urib.query(strconst::sort,strconst::name);

	this->_request << boost::network::header(strconst::magni_token_header, this->_magni_token);

	this->_request.uri(search_uri);

	this->_response = this->_client.get(this->_request);
	headers_range<http_client::response>::type headers_ = this->_response.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	body_range<http_client::response>::type body_;


	body_ = body(this->_response).range();


	oss.str("");
	oss << body_;

	Json::Value body;
	Json::Reader jreader;

	jreader.parse(oss.str(), body);

	Json::StyledWriter writer;

	/**
	 * create folder structure representation
	 */

	Json::Value fs = Json::Value(Json::objectValue);
	std::ostringstream oss_index;
	std::vector<std::string> splits;
	std::map<std::string,std::map<std::string,Json::Value>> dirfs;
	Json::Value::Members members;
	Json::Value crumbs;
	std::vector<std::string> path_components;
	std::string name;
	std::string path;

	std::vector<std::string> paths;
	Json::Value folders = Json::Value(Json::objectValue);
	folders[strconst::slash] = Json::Value(Json::objectValue);
	folders[strconst::slash][strconst::metadata] = Json::Value(Json::objectValue);
	folders[strconst::slash][strconst::items]    = Json::Value(Json::objectValue);
	Json::Value items = Json::Value(Json::objectValue);

	Json::Value itembody;
	for(Json::ArrayIndex i =0;i<body[strconst::rows].size();++i) {

		Json::Value item_url = body[strconst::rows][i];
		this->_request.uri(item_url[strconst::links][strconst::file].asString());
		this->_response = this->_client.get(this->_request);
		body_range<http_client::response>::type response_itembody = boost::network::http::body(this->_response).range();
		oss.str("");
		oss << response_itembody;
		jreader.parse(oss.str(),itembody);

		name = itembody[strconst::name].asString();
		path_components.clear();
		path_components.push_back(itembody[strconst::path].asString());
		path_components.push_back(name);
		path = boost::join(path_components,strconst::slash);
		if(path[0]!=strconst::slash[0])
		{
			path.insert(path.begin(),strconst::slash[0]);
		}
		paths.push_back(path);
		if(itembody[strconst::is_folder].asBool())
		{
			folders[path] = Json::Value(Json::objectValue);
			folders[path][strconst::metadata] = Json::Value(Json::objectValue);
			folders[path][strconst::items]    = Json::Value(Json::objectValue);
		}
		items[path] = itembody;

	}

	for(auto&& item : items)
	{
		path = strconst::slash+ item[strconst::path].asString();
		const std::string& name = item[strconst::name].asString();
		folders[path][strconst::items][name] = item;
	}
	headers_and_body[strconst::body] = body;
	headers_and_body[strconst::body][strconst::details][strconst::folders] = folders;
	headers_and_body[strconst::body][strconst::details][strconst::items]   = items;


	MagniInterface::_search_response = headers_and_body;
	return headers_and_body;

}

int MagniInterface::fuse_getattr(const char *p_path, struct stat *p_stbuf) {

	std::cout << __FUNCTION__ << " " << p_path << std::endl;std::cout.flush();
	int res = 0;

	memset(p_stbuf, 0, sizeof(struct stat));

	if (!_instance->_getFolder(p_path).isNull()) {
		p_stbuf->st_mode = S_IFDIR | 0755;
		p_stbuf->st_nlink = 2+_instance->_getFolder(p_path)[strconst::items].size();
	} else if (!_instance->_getItem(p_path).isNull()) {
		p_stbuf->st_mode = S_IFREG | 0444;
		p_stbuf->st_nlink = 1;
		p_stbuf->st_size = _instance->_getItem(p_path)[strconst::size].asUInt64();
	} else {
		std::cout << "\n------------\n" << __FUNCTION__ << " "  << p_path << std::endl;std::cout.flush();
		res = -ENOENT;
	}
	if(res!=-ENOENT)
	{
		if(!_instance->_getItem(p_path)[strconst::changed_at].isNull())
		{
			const char *changed_at_time = _instance->_getItem(p_path)[strconst::changed_at].asCString();
			tm tmval;
			strptime(changed_at_time,"%Y-%m-%dT%H:%M:%S",&tmval);
			time_t t = mktime(&tmval);
			p_stbuf->st_mtim = {t,0};
		}
	}
	return res;
}

int
MagniInterface::fuse_readdir
	(const char *p_path,
	void *p_buf,
	fuse_fill_dir_t p_filler,
	off_t p_offset,
	struct fuse_file_info *p_fi)
{

	(void) p_offset;
	(void) p_fi;
	std::cout << __FUNCTION__ << " " << p_path << std::endl;std::cout.flush();

	std::vector<std::string> members;

	Json::Value folder =
			_instance->_getFolder(p_path)[strconst::items];
	if (!folder.isNull()) {
		int offset = 0;
		p_filler(p_buf, ".", NULL, 0);
		p_filler(p_buf, "..", NULL, 0);
		members = folder.getMemberNames();
		for (auto&& member : members) {
			const char *name = folder[member][strconst::name].asCString();
			p_filler(p_buf, name + offset, NULL, 0);
		}
		return 0;
	} else {
		std::cout << __FUNCTION__ << " " << p_path << std::endl;std::cout.flush();
		return -ENOENT;
	}

}


int
MagniInterface::fuse_open
	(const char *p_path,
	struct fuse_file_info *p_fi)
{


	headers_range<http_client::response>::type headers_;

	std::unique_ptr<std::ostringstream> uposs(new std::ostringstream());
	std::unique_ptr<body_range<http_client::response>::type> upbody_response(new body_range<http_client::response>::type());

	Json::Value headers_and_body;

	Json::Value file = _instance->_getItem(p_path);


	Json::Value download_link = file[strconst::links][strconst::download_link];

	_instance->_request.remove_header(strconst::magni_token_header);
	_instance->_request << boost::network::header(strconst::magni_token_header,_instance->_magni_token);
	_instance->_request << boost::network::header(strconst::accept, strconst::bifrost_encoding);
	_instance->_request << boost::network::header(strconst::accept_encoding, strconst::gzip_deflate_encoding);
	headers_ = _instance->_request.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	_instance->_request.uri(download_link.asString());
	try {
		_instance->_response = _instance->_client.get(_instance->_request);
	} catch (boost::system::system_error& e) {
		throw e;
	}
	headers_ = _instance->_response.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}


	*upbody_response = boost::network::http::body(_instance->_response).range();


	uposs->str("");
	*uposs << *upbody_response;

	std::unique_ptr<Json::Value> upbody(new Json::Value);
	Json::Reader jreader;

	jreader.parse(uposs->str(), *upbody);


	_instance->_request.remove_header(strconst::magni_token_header);
	_instance->_request << boost::network::header(strconst::magni_token_header,_instance->_magni_token);
	_instance->_request.uri((*upbody)["download"].asString());
	headers_ = _instance->_request.headers();
	for(auto&& header : headers_) {
		headers_and_body[strconst::headers][header.first] = header.second;
	}
	try {
		_instance->_response = _instance->_client.get(_instance->_request);
	} catch (boost::system::system_error& e) {
		throw e;
	}
	headers_ = _instance->_response.headers();
	for(auto&& header : headers_) {
		std::cout << header.first << " : " << header.second << std::endl;std::cout.flush();
		headers_and_body[strconst::headers][header.first] = header.second;
	}

	*upbody_response = boost::network::http::body(_instance->_response).range();

	uposs->str("");
	*uposs << *upbody_response;

	upbody_response.release();

	std::vector<std::string> path_components;
	path_components.push_back(".root");
	path_components.push_back(file[strconst::path].asString());
	path_components.push_back(file[strconst::name].asString());
	std::string shadow_path = boost::join(path_components,strconst::slash);
	int fd = openat(AT_FDCWD,shadow_path.c_str(),O_RDWR|O_CREAT|O_TRUNC,S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH|S_IWOTH);
	const size_t data_size = uposs->str().size();
	const char *data = uposs->str().c_str();
	const size_t N = 1024;
	size_t offset = 0;
	while(true)
	{
		if((offset+N)>data_size)
		{
			if(offset<data_size)
			{
				write(fd,data+offset,data_size-offset);
			}
			break;
		}
		else
		{
			write(fd,data+offset,N);
			offset += N;
		}
	}


	lseek(fd,0,SEEK_SET);
	_instance->_downloaded_files[p_path] = shadow_path;

	p_fi->fh = fd;
	return 0;
}


int
MagniInterface::fuse_read
	(const char *p_path,
	char *p_buf,
	size_t p_size,
	off_t p_offset,
	struct fuse_file_info *p_fi)
{
	return read(p_fi->fh,p_buf,p_size);
}

int
MagniInterface::fuse_release
	(const char *path,
	struct fuse_file_info *fi)
{
	std::vector<std::string> common_paths;
	common_paths.push_back("/");
	common_paths.push_back(".");
	common_paths.push_back("..");
	for(auto && cp : common_paths)
	{
		if(cp==path)
		{
			return 0;
		}
	}

	std::vector<std::string> members;

	Json::Value folder =
			_instance->_getFolder(path);
	if(!folder.isNull())
	{
		return 0;
	}
	auto shadow_file_it = _instance->_downloaded_files.find(path);
	if(shadow_file_it==_instance->_downloaded_files.end())
	{
		return -ENOENT;
	}
	else
	{
		return remove(shadow_file_it->second.c_str());
	}


}

int MagniInterface::fuse_access(const char *p_path,int p_mask) {
	std::cout << __FUNCTION__ << " " << p_path << " " << p_mask << std::endl;std::cout.flush();
	return 0;
}

fuse_operations MagniInterface::get_operations() {
	this->_fuse_operations = {0};
	this->_fuse_operations.getattr = MagniInterface::fuse_getattr;
	this->_fuse_operations.readdir = MagniInterface::fuse_readdir;
	this->_fuse_operations.open = MagniInterface::fuse_open;
	this->_fuse_operations.read = MagniInterface::fuse_read;
	this->_fuse_operations.release = MagniInterface::fuse_release;
	this->_fuse_operations.access = MagniInterface::fuse_access;
	this->_fuse_operations.readlink = readlink;
	return this->_fuse_operations;
}

Json::Value&
MagniInterface::_getItem
	(const char *p_path)
{
	return _search_response[strconst::body][strconst::details][strconst::items][p_path];
}

Json::Value&
MagniInterface::_getFolder
	(const char *p_path)
{
	return _search_response[strconst::body][strconst::details][strconst::folders][p_path];
}
