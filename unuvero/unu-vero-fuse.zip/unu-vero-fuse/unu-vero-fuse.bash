#!/bin/bash
sudo ./unu-vero-fuse -f $1 -o allow_other -o auto_unmount
